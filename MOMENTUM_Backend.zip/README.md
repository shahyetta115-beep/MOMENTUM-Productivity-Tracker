# MOMENTUM Backend (Beginner Prototype)

A small FastAPI + SQLite backend for task tracking, daily productivity entries, and basic analytics.

## Requirements
- Python 3.10 or newer
- Internet connection for installing packages

## Run on Windows
Open Command Prompt or the VS Code terminal inside this folder:

```bat
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
uvicorn app.main:app --reload
```

If `py` does not work, try `python` instead.

Open:
- API home: http://127.0.0.1:8000/
- Interactive API docs: http://127.0.0.1:8000/docs

The SQLite file `momentum.db` is created automatically in the folder where you start the server.

## Test quickly in `/docs`
1. `POST /tasks`:
```json
{
  "title": "Study Python",
  "description": "Practise FastAPI",
  "priority": "high",
  "status": "pending",
  "due_date": null
}
```
2. `GET /tasks` to see the task.
3. `PUT /tasks/1` to update it (use the actual ID returned):
```json
{"status": "completed"}
```
4. `DELETE /tasks/1` to delete it.
5. `POST /daily-entry`:
```json
{
  "date": "2026-10-18",
  "study_hours": 2,
  "sleep_hours": 7.5,
  "screen_time_hours": 4,
  "exercise_minutes": 20,
  "mood": "good",
  "notes": "Worked on MOMENTUM"
}
```
6. Try `GET /analytics/summary`, `GET /analytics/daily`, and `GET /analytics/export.csv`.

## Frontend integration
During local development, the API base URL is `http://127.0.0.1:8000`.
This prototype enables CORS for convenient local testing. Before public deployment, restrict `allow_origins` in `app/main.py` to the real frontend origin.

Example JavaScript:
```javascript
const response = await fetch("http://127.0.0.1:8000/tasks");
const tasks = await response.json();
console.log(tasks);
```

## Current limitations
This is a prototype, not a production-ready application:
- Signup/login, JWT authentication, and user ownership are not implemented.
- Tasks and entries are currently shared in one local database.
- Habits, goals, and mood-history/study-session modules are not implemented yet.
- Do not expose this prototype publicly or use real private user data until authentication and access controls are added.
- Power BI can import the CSV export; refresh and connection configuration depend on your Power BI setup.
