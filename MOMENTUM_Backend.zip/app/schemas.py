from datetime import date
from pydantic import BaseModel, Field
from typing import Optional

class TaskCreate(BaseModel):
    title: str = Field(min_length=1, max_length=150)
    description: str = ""
    priority: str = "medium"
    status: str = "pending"
    due_date: Optional[date] = None

class TaskUpdate(BaseModel):
    title: Optional[str] = Field(default=None, min_length=1, max_length=150)
    description: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[str] = None
    due_date: Optional[date] = None

class TaskOut(BaseModel):
    id: int
    title: str
    description: str
    priority: str
    status: str
    due_date: Optional[date] = None
    class Config:
        from_attributes = True

class DailyEntryCreate(BaseModel):
    date: date
    study_hours: float = Field(default=0, ge=0, le=24)
    sleep_hours: float = Field(default=0, ge=0, le=24)
    screen_time_hours: float = Field(default=0, ge=0, le=24)
    exercise_minutes: int = Field(default=0, ge=0, le=1440)
    mood: str = "okay"
    notes: str = ""

class DailyEntryOut(BaseModel):
    id: int
    date: date
    study_hours: float
    sleep_hours: float
    screen_time_hours: float
    exercise_minutes: int
    mood: str
    notes: str
    class Config:
        from_attributes = True
