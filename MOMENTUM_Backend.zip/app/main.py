from datetime import date
from fastapi import FastAPI, Depends, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import func
import csv
import io

from .database import Base, engine, get_db
from . import models, schemas

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="MOMENTUM Backend",
    description="Beginner-friendly productivity tracking API",
    version="1.0.0",
)

# For local development only. Restrict this to your frontend origin before deployment.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def home():
    return {"message": "MOMENTUM API is running", "docs": "/docs"}

# TASKS
@app.post("/tasks", response_model=schemas.TaskOut, status_code=201)
def create_task(payload: schemas.TaskCreate, db: Session = Depends(get_db)):
    task = models.Task(**payload.model_dump())
    db.add(task)
    db.commit()
    db.refresh(task)
    return task

@app.get("/tasks", response_model=list[schemas.TaskOut])
def list_tasks(status: str | None = None, db: Session = Depends(get_db)):
    query = db.query(models.Task)
    if status:
        query = query.filter(models.Task.status == status)
    return query.order_by(models.Task.id.desc()).all()

@app.get("/tasks/{task_id}", response_model=schemas.TaskOut)
def get_task(task_id: int, db: Session = Depends(get_db)):
    task = db.query(models.Task).filter(models.Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@app.put("/tasks/{task_id}", response_model=schemas.TaskOut)
def update_task(task_id: int, payload: schemas.TaskUpdate, db: Session = Depends(get_db)):
    task = db.query(models.Task).filter(models.Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(task, key, value)
    db.commit()
    db.refresh(task)
    return task

@app.delete("/tasks/{task_id}", status_code=204)
def delete_task(task_id: int, db: Session = Depends(get_db)):
    task = db.query(models.Task).filter(models.Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    db.delete(task)
    db.commit()
    return Response(status_code=204)

# DAILY ENTRIES
@app.post("/daily-entry", response_model=schemas.DailyEntryOut, status_code=201)
def create_daily_entry(payload: schemas.DailyEntryCreate, db: Session = Depends(get_db)):
    entry = models.DailyEntry(**payload.model_dump())
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry

@app.get("/daily-entry", response_model=list[schemas.DailyEntryOut])
def list_daily_entries(
    start_date: date | None = None,
    end_date: date | None = None,
    db: Session = Depends(get_db)
):
    query = db.query(models.DailyEntry)
    if start_date:
        query = query.filter(models.DailyEntry.date >= start_date)
    if end_date:
        query = query.filter(models.DailyEntry.date <= end_date)
    return query.order_by(models.DailyEntry.date.desc()).all()

@app.put("/daily-entry/{entry_id}", response_model=schemas.DailyEntryOut)
def update_daily_entry(entry_id: int, payload: schemas.DailyEntryCreate, db: Session = Depends(get_db)):
    entry = db.query(models.DailyEntry).filter(models.DailyEntry.id == entry_id).first()
    if not entry:
        raise HTTPException(status_code=404, detail="Daily entry not found")
    for key, value in payload.model_dump().items():
        setattr(entry, key, value)
    db.commit()
    db.refresh(entry)
    return entry

# ANALYTICS
@app.get("/analytics/summary")
def analytics_summary(db: Session = Depends(get_db)):
    total_tasks = db.query(models.Task).count()
    completed_tasks = db.query(models.Task).filter(models.Task.status == "completed").count()
    total_study = db.query(func.coalesce(func.sum(models.DailyEntry.study_hours), 0)).scalar()
    average_sleep = db.query(func.avg(models.DailyEntry.sleep_hours)).scalar()
    average_screen = db.query(func.avg(models.DailyEntry.screen_time_hours)).scalar()
    return {
        "total_tasks": total_tasks,
        "completed_tasks": completed_tasks,
        "pending_tasks": total_tasks - completed_tasks,
        "task_completion_percent": round(completed_tasks / total_tasks * 100, 2) if total_tasks else 0,
        "total_study_hours": round(float(total_study or 0), 2),
        "average_sleep_hours": round(float(average_sleep or 0), 2) if average_sleep is not None else 0,
        "average_screen_time_hours": round(float(average_screen or 0), 2) if average_screen is not None else 0,
    }

@app.get("/analytics/daily")
def analytics_daily(db: Session = Depends(get_db)):
    rows = db.query(
        models.DailyEntry.date,
        func.sum(models.DailyEntry.study_hours).label("study_hours"),
        func.avg(models.DailyEntry.sleep_hours).label("sleep_hours"),
        func.avg(models.DailyEntry.screen_time_hours).label("screen_time_hours"),
        func.sum(models.DailyEntry.exercise_minutes).label("exercise_minutes"),
    ).group_by(models.DailyEntry.date).order_by(models.DailyEntry.date).all()
    return [
        {
            "date": row.date.isoformat(),
            "study_hours": round(float(row.study_hours or 0), 2),
            "sleep_hours": round(float(row.sleep_hours or 0), 2),
            "screen_time_hours": round(float(row.screen_time_hours or 0), 2),
            "exercise_minutes": int(row.exercise_minutes or 0),
        }
        for row in rows
    ]

@app.get("/analytics/export.csv")
def export_analytics_csv(db: Session = Depends(get_db)):
    rows = db.query(models.DailyEntry).order_by(models.DailyEntry.date).all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["date", "study_hours", "sleep_hours", "screen_time_hours", "exercise_minutes", "mood", "notes"])
    for row in rows:
        writer.writerow([row.date.isoformat(), row.study_hours, row.sleep_hours,
                         row.screen_time_hours, row.exercise_minutes, row.mood, row.notes])
    return Response(
        content=output.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=momentum_analytics.csv"},
    )
