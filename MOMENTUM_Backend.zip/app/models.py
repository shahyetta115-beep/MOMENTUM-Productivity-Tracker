from sqlalchemy import Column, Integer, String, Float, Date, Text
from .database import Base

class Task(Base):
    __tablename__ = "tasks"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(150), nullable=False)
    description = Column(Text, default="")
    priority = Column(String(20), default="medium")
    status = Column(String(20), default="pending")
    due_date = Column(Date, nullable=True)

class DailyEntry(Base):
    __tablename__ = "daily_entries"
    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date, nullable=False, index=True)
    study_hours = Column(Float, default=0)
    sleep_hours = Column(Float, default=0)
    screen_time_hours = Column(Float, default=0)
    exercise_minutes = Column(Integer, default=0)
    mood = Column(String(30), default="okay")
    notes = Column(Text, default="")
