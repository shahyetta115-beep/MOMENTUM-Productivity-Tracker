import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Leaf, LayoutDashboard, CheckSquare, CalendarDays, ChartNoAxesCombined,
  Plus, Search, CircleCheck, Clock3, Sprout, Moon, Monitor, Dumbbell,
  Smile, Meh, Frown, Trash2, RefreshCw, ArrowUpRight, Menu, X
} from "lucide-react";
import "./styles.css";

const API = "http://127.0.0.1:8000";
const today = () => new Date().toLocaleDateString("en-CA");
const emptyDaily = () => ({
  date: today(), study_hours: 0, sleep_hours: 8, screen_time_hours: 0,
  exercise_minutes: 0, mood: "okay", notes: ""
});

function App() {
  const [page, setPage] = useState("Overview");
  const [tasks, setTasks] = useState([]);
  const [summary, setSummary] = useState(null);
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [daily, setDaily] = useState(emptyDaily());
  const [mobileNav, setMobileNav] = useState(false);
  const [taskForm, setTaskForm] = useState({
    title: "", description: "", priority: "medium", status: "pending", due_date: ""
  });

  async function api(path, options = {}) {
    const response = await fetch(`${API}${path}`, {
      ...options,
      headers: { "Content-Type": "application/json", ...(options.headers || {}) }
    });
    if (!response.ok) {
      let detail = `Request failed (${response.status})`;
      try {
        const data = await response.json();
        detail = Array.isArray(data.detail) ? data.detail.map(x => x.msg).join(", ") : (data.detail || detail);
      } catch {}
      throw new Error(detail);
    }
    if (response.status === 204) return null;
    return response.json();
  }

  async function loadData() {
    setLoading(true);
    setError("");
    try {
      const [taskData, summaryData, dailyData] = await Promise.all([
        api("/tasks"), api("/analytics/summary"), api("/daily-entry")
      ]);
      setTasks(taskData);
      setSummary(summaryData);
      setEntries(dailyData);
    } catch (e) {
      setError(`${e.message}. Make sure your FastAPI backend is running in VS Code.`);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadData(); }, []);

  const completed = tasks.filter(t => t.status === "completed").length;
  const pending = tasks.filter(t => t.status !== "completed").length;
  const progress = tasks.length ? Math.round((completed / tasks.length) * 100) : 0;
  const visibleTasks = useMemo(() => tasks.filter(t => {
    const matchesFilter = filter === "all" || (filter === "completed" ? t.status === "completed" : t.status !== "completed");
    const matchesSearch = `${t.title} ${t.description || ""}`.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  }), [tasks, filter, search]);

  async function addTask(e) {
    e.preventDefault();
    setNotice(""); setError("");
    try {
      const created = await api("/tasks", {
        method: "POST",
        body: JSON.stringify({ ...taskForm, due_date: taskForm.due_date || null })
      });
      setTasks(prev => [created, ...prev]);
      setTaskForm({ title: "", description: "", priority: "medium", status: "pending", due_date: "" });
      setShowTaskForm(false);
      setNotice("Task added successfully.");
      const s = await api("/analytics/summary"); setSummary(s);
    } catch (e) { setError(e.message); }
  }

  async function toggleTask(task) {
    const nextStatus = task.status === "completed" ? "pending" : "completed";
    try {
      const updated = await api(`/tasks/${task.id}`, {
        method: "PUT",
        body: JSON.stringify({ status: nextStatus })
      });
      setTasks(prev => prev.map(t => t.id === task.id ? updated : t));
      setNotice(nextStatus === "completed" ? "Nice work — task completed!" : "Task moved back to pending.");
      setSummary(await api("/analytics/summary"));
    } catch (e) { setError(e.message); }
  }

  async function deleteTask(id) {
    if (!window.confirm("Delete this task?")) return;
    try {
      await api(`/tasks/${id}`, { method: "DELETE" });
      setTasks(prev => prev.filter(t => t.id !== id));
      setSummary(await api("/analytics/summary"));
      setNotice("Task deleted.");
    } catch (e) { setError(e.message); }
  }

  async function saveDaily(e) {
    e.preventDefault(); setError(""); setNotice("");
    try {
      const existing = entries.find(x => x.date === daily.date);
      let saved;
      if (existing) {
        saved = await api(`/daily-entry/${existing.id}`, {
          method: "PUT", body: JSON.stringify({
            ...daily, study_hours: Number(daily.study_hours), sleep_hours: Number(daily.sleep_hours),
            screen_time_hours: Number(daily.screen_time_hours), exercise_minutes: Number(daily.exercise_minutes)
          })
        });
        setEntries(prev => prev.map(x => x.id === existing.id ? saved : x));
      } else {
        saved = await api("/daily-entry", {
          method: "POST", body: JSON.stringify({
            ...daily, study_hours: Number(daily.study_hours), sleep_hours: Number(daily.sleep_hours),
            screen_time_hours: Number(daily.screen_time_hours), exercise_minutes: Number(daily.exercise_minutes)
          })
        });
        setEntries(prev => [saved, ...prev]);
      }
      setNotice("Daily entry saved.");
      setSummary(await api("/analytics/summary"));
    } catch (e) { setError(e.message); }
  }

  const nav = [
    { name: "Overview", icon: LayoutDashboard },
    { name: "My tasks", icon: CheckSquare },
    { name: "Daily journal", icon: CalendarDays },
    { name: "Insights", icon: ChartNoAxesCombined }
  ];

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
      <div className="brand"><span className="brand-mark"><Leaf size={21}/></span><span>MOMENTUM<small>YOUR DAILY RHYTHM</small></span><button className="close-nav" onClick={() => setMobileNav(false)}><X size={18}/></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>{nav.map(item => <button key={item.name} className={`nav-item ${page === item.name ? "active" : ""}`} onClick={() => { setPage(item.name); setMobileNav(false); }}><item.icon size={18}/>{item.name}{item.name === "My tasks" && <span className="nav-count">{pending}</span>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="leaf-card"><Sprout size={20}/><strong>Small steps count.</strong><p>Progress grows when you show up, one day at a time.</p><div className="leaf-line"><span style={{width: `${progress}%`}}/></div><small>{progress}% of tasks complete</small></div><div className="profile"><div className="avatar">M</div><div><strong>Your workspace</strong><small>Personal productivity</small></div><span className="online-dot"/></div></div>
    </aside>
    {mobileNav && <button className="scrim" onClick={() => setMobileNav(false)} aria-label="Close menu"/>}
    <main className="main-content">
      <header className="topbar"><button className="mobile-menu" onClick={() => setMobileNav(true)}><Menu/></button><div className="breadcrumbs">Workspace <span>/</span> <strong>{page}</strong></div><div className="top-actions"><span className="today-pill"><span className="status-dot"/> Local mode</span><button className="icon-button" title="Refresh data" onClick={loadData}><RefreshCw size={17}/></button></div></header>
      <div className="page-wrap">
        <div className="welcome-row"><div><div className="eyebrow">{new Date().toLocaleDateString(undefined, {weekday:"long", month:"long", day:"numeric"})}</div><h1>{page === "Overview" ? "A little progress, every day." : page}</h1><p className="subtitle">{page === "Overview" ? "Make space for what matters. You're building your rhythm." : page === "My tasks" ? "Keep your priorities clear and your next step simple." : page === "Daily journal" ? "Check in with yourself and capture how today went." : "Notice your patterns. Celebrate the small wins."}</p></div><button className="primary-button" onClick={() => { setPage("My tasks"); setShowTaskForm(true); }}><Plus size={17}/> Add a task</button></div>
        {error && <div className="alert error"><strong>Couldn't connect:</strong> {error}<button onClick={() => setError("")}>Dismiss</button></div>}
        {notice && <div className="alert success"><CircleCheck size={17}/>{notice}<button onClick={() => setNotice("")}>Dismiss</button></div>}
        {loading ? <div className="loading-card"><RefreshCw className="spin" size={22}/><span>Loading your workspace…</span></div> : <>
          {page === "Overview" && <Overview tasks={tasks} summary={summary} completed={completed} pending={pending} progress={progress} entries={entries} onTasks={() => setPage("My tasks")} onToggle={toggleTask}/>}
          {page === "My tasks" && <Tasks tasks={visibleTasks} filter={filter} setFilter={setFilter} search={search} setSearch={setSearch} showForm={showTaskForm} setShowForm={setShowTaskForm} taskForm={taskForm} setTaskForm={setTaskForm} addTask={addTask} toggleTask={toggleTask} deleteTask={deleteTask}/>}
          {page === "Daily journal" && <DailyJournal daily={daily} setDaily={setDaily} saveDaily={saveDaily} entries={entries}/>}
          {page === "Insights" && <Insights tasks={tasks} summary={summary} entries={entries} completed={completed} pending={pending}/>}
        </>}
        <footer className="footer"><span><Leaf size={14}/> A calmer way to move forward.</span><span>MOMENTUM <b>•</b> Built for steady progress</span></footer>
      </div>
    </main>
  </div>;
}

function Overview({tasks, summary, completed, pending, progress, entries, onTasks, onToggle}) {
  const recent = [...tasks].sort((a,b) => b.id-a.id).slice(0,4);
  const todayEntry = entries.find(e => e.date === today());
  return <div className="content-grid">
    <section className="stat-grid">
      <Stat label="Total tasks" value={tasks.length} note="All your priorities" icon={CheckSquare} tint="sage"/>
      <Stat label="Completed" value={completed} note="Every win matters" icon={CircleCheck} tint="mint"/>
      <Stat label="Still in progress" value={pending} note="One step at a time" icon={Clock3} tint="sand"/>
      <Stat label="Study hours today" value={todayEntry ? Number(todayEntry.study_hours).toFixed(1) : "0.0"} note="Keep your focus gentle" icon={Sprout} tint="blue"/>
    </section>
    <section className="panel progress-panel"><div className="panel-heading"><div><span className="eyebrow">YOUR MOMENTUM</span><h2>Today's progress</h2></div><span className="round-icon"><Sprout size={20}/></span></div><div className="progress-body"><div className="progress-ring" style={{"--progress": `${progress * 3.6}deg`}}><div><strong>{progress}%</strong><small>complete</small></div></div><div className="progress-copy"><h3>{progress === 100 && tasks.length ? "Beautifully done!" : progress > 0 ? "You're finding your rhythm." : "Start with one small step."}</h3><p>{completed} of {tasks.length} tasks completed. Consistency matters more than perfection.</p><button className="text-button" onClick={onTasks}>View your tasks <ArrowUpRight size={15}/></button></div></div><div className="progress-legend"><span><i className="legend-sage"/>Completed <b>{completed}</b></span><span><i className="legend-pale"/>Remaining <b>{pending}</b></span></div></section>
    <section className="panel tasks-panel"><div className="panel-heading"><div><span className="eyebrow">YOUR NEXT STEPS</span><h2>Task list</h2></div><button className="text-button" onClick={onTasks}>View all <ArrowUpRight size={15}/></button></div>{recent.length ? <div className="task-list compact">{recent.map(t => <TaskRow key={t.id} task={t} onToggle={onToggle}/>)}</div> : <EmptyState title="Your list starts here" text="Add a task to give your day a little direction."/>}</section>
    <section className="panel gentle-panel"><div className="gentle-illustration"><Sprout size={34}/><span/><i/></div><span className="eyebrow">A GENTLE REMINDER</span><h2>Progress isn't always loud.</h2><p>Showing up, taking a break, trying again — it all counts. Keep moving at your own pace.</p><div className="gentle-bottom"><span>Grow at your own pace</span><Leaf size={17}/></div></section>
  </div>;
}

function Stat({label, value, note, icon: Icon, tint}) {
  return <div className="stat-card"><div className={`stat-icon ${tint}`}><Icon size={19}/></div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-note">{note}</div></div>;
}

function Tasks({tasks, filter, setFilter, search, setSearch, showForm, setShowForm, taskForm, setTaskForm, addTask, toggleTask, deleteTask}) {
  return <div className="panel task-manager"><div className="task-toolbar"><div className="filter-tabs">{[["all","All tasks"],["pending","To do"],["completed","Completed"]].map(([id,label]) => <button key={id} className={filter===id?"selected":""} onClick={() => setFilter(id)}>{label}</button>)}</div><div className="search-box"><Search size={16}/><input placeholder="Search tasks..." value={search} onChange={e=>setSearch(e.target.value)}/></div></div>
    {showForm && <form className="task-form" onSubmit={addTask}><div className="form-title"><h3>Create a task</h3><button type="button" className="icon-button" onClick={() => setShowForm(false)}><X size={17}/></button></div><label>Task title<input required maxLength="150" placeholder="e.g. Review lecture notes" value={taskForm.title} onChange={e=>setTaskForm({...taskForm,title:e.target.value})}/></label><label>Description <textarea placeholder="Add a little detail (optional)" value={taskForm.description} onChange={e=>setTaskForm({...taskForm,description:e.target.value})}/></label><div className="form-row"><label>Priority<select value={taskForm.priority} onChange={e=>setTaskForm({...taskForm,priority:e.target.value})}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></label><label>Due date<input type="date" value={taskForm.due_date} onChange={e=>setTaskForm({...taskForm,due_date:e.target.value})}/></label></div><div className="form-actions"><button type="button" className="secondary-button" onClick={() => setShowForm(false)}>Cancel</button><button className="primary-button" type="submit"><Plus size={16}/> Save task</button></div></form>}
    <div className="task-list">{tasks.length ? tasks.map(t=><div className="task-row-wrap" key={t.id}><TaskRow task={t} onToggle={toggleTask}/><button className="delete-button" title="Delete task" onClick={()=>deleteTask(t.id)}><Trash2 size={16}/></button></div>) : <EmptyState title="Nothing on this list" text="Try another filter or add a new task."/>}</div>
    <div className="list-footer">{tasks.length} {tasks.length===1?"task":"tasks"} shown</div>
  </div>;
}

function TaskRow({task, onToggle}) {
  return <div className="task-row"><button className={`task-check ${task.status==="completed"?"checked":""}`} onClick={()=>onToggle(task)} title={task.status==="completed"?"Mark pending":"Mark completed"}>{task.status==="completed"&&<CircleCheck size={16}/>}</button><div className="task-details"><strong className={task.status==="completed"?"task-done":""}>{task.title}</strong>{task.description&&<p>{task.description}</p>}<div className="task-meta">{task.due_date&&<span><CalendarDays size={13}/>{task.due_date}</span>}<span className={`priority priority-${(task.priority||"medium").toLowerCase()}`}>{task.priority||"medium"} priority</span></div></div><span className={`status-badge ${task.status==="completed"?"is-complete":""}`}>{task.status==="completed"?"Completed":"To do"}</span></div>;
}

function DailyJournal({daily, setDaily, saveDaily, entries}) {
  const update = (key,value) => setDaily(prev=>({...prev,[key]:value}));
  return <div className="journal-grid"><form className="panel journal-form" onSubmit={saveDaily}><div className="panel-heading"><div><span className="eyebrow">DAILY CHECK-IN</span><h2>How was your day?</h2></div><span className="round-icon"><CalendarDays size={20}/></span></div><p className="muted">A few simple notes help you understand your habits over time.</p><label>Date<input type="date" required value={daily.date} onChange={e=>update("date",e.target.value)}/></label><div className="journal-metrics"><MetricInput icon={Sprout} label="Study hours" suffix="hrs" value={daily.study_hours} max="24" step="0.5" onChange={v=>update("study_hours",v)}/><MetricInput icon={Moon} label="Sleep" suffix="hrs" value={daily.sleep_hours} max="24" step="0.5" onChange={v=>update("sleep_hours",v)}/><MetricInput icon={Monitor} label="Screen time" suffix="hrs" value={daily.screen_time_hours} max="24" step="0.5" onChange={v=>update("screen_time_hours",v)}/><MetricInput icon={Dumbbell} label="Exercise" suffix="mins" value={daily.exercise_minutes} max="1440" step="5" onChange={v=>update("exercise_minutes",v)}/></div><label>How are you feeling?</label><div className="mood-options">{[{id:"great",label:"Great",Icon:Smile},{id:"okay",label:"Okay",Icon:Meh},{id:"low",label:"Low",Icon:Frown}].map(m=><button type="button" key={m.id} className={`mood-option ${daily.mood===m.id?"chosen":""}`} onClick={()=>update("mood",m.id)}><m.Icon size={22}/>{m.label}</button>)}</div><label>Notes<textarea rows="3" placeholder="Anything you'd like to remember about today?" value={daily.notes} onChange={e=>update("notes",e.target.value)}/></label><button className="primary-button wide" type="submit"><CircleCheck size={17}/> Save daily entry</button></form>
  <div className="panel journal-history"><div className="panel-heading"><div><span className="eyebrow">LOOKING BACK</span><h2>Recent check-ins</h2></div></div>{entries.length? <div className="history-list">{[...entries].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,7).map(e=><div className="history-item" key={e.id}><div className="history-date"><strong>{new Date(e.date+"T12:00:00").toLocaleDateString(undefined,{day:"2-digit"})}</strong><small>{new Date(e.date+"T12:00:00").toLocaleDateString(undefined,{month:"short"})}</small></div><div className="history-info"><strong>{e.mood==="great"?"Feeling great":e.mood==="low"?"A low-key day":"Steady day"}</strong><small>{e.study_hours} study hrs · {e.sleep_hours} sleep hrs</small>{e.notes&&<p>{e.notes}</p>}</div><span className={`mood-dot mood-${e.mood}`}/></div>)}</div>:<EmptyState title="Your story starts today" text="Save your first check-in to build a gentle record of your days."/>}</div></div>;
}

function MetricInput({icon:Icon,label,suffix,value,max,step,onChange}) {
  return <label className="metric-input"><span className="metric-label"><Icon size={16}/>{label}</span><span className="number-input"><input type="number" min="0" max={max} step={step} value={value} onChange={e=>onChange(e.target.value)}/><small>{suffix}</small></span></label>;
}

function Insights({tasks, summary, entries, completed, pending}) {
  const totalStudy = entries.reduce((n,e)=>n+Number(e.study_hours||0),0);
  const avgSleep = entries.length ? entries.reduce((n,e)=>n+Number(e.sleep_hours||0),0)/entries.length : 0;
  const avgScreen = entries.length ? entries.reduce((n,e)=>n+Number(e.screen_time_hours||0),0)/entries.length : 0;
  const maxStudy = Math.max(1,...entries.map(e=>Number(e.study_hours||0)));
  return <div className="insights-grid"><section className="panel insight-main"><div className="panel-heading"><div><span className="eyebrow">YOUR PATTERNS</span><h2>Progress at a glance</h2></div><span className="round-icon"><ChartNoAxesCombined size={20}/></span></div><div className="insight-stats"><div><small>Total study hours</small><strong>{totalStudy.toFixed(1)}<em> hrs</em></strong></div><div><small>Average sleep</small><strong>{avgSleep.toFixed(1)}<em> hrs</em></strong></div><div><small>Average screen time</small><strong>{avgScreen.toFixed(1)}<em> hrs</em></strong></div></div><h3 className="chart-title">Study hours by day</h3>{entries.length ? <div className="bar-chart">{[...entries].sort((a,b)=>a.date.localeCompare(b.date)).slice(-7).map(e=><div className="bar-column" key={e.id}><div className="bar-track"><div className="bar" style={{height:`${Math.max(5,Number(e.study_hours)/maxStudy*100)}%`}} title={`${e.study_hours} hours`}/></div><small>{new Date(e.date+"T12:00:00").toLocaleDateString(undefined,{weekday:"short"})}</small></div>)}</div>:<EmptyState title="Your chart is waiting" text="Add a few daily entries and your study trends will appear here."/>}</section><section className="panel insight-side"><span className="eyebrow">TASK HEALTH</span><h2>Keep a steady pace</h2><div className="mini-progress"><div><span>Completed</span><strong>{completed}</strong></div><div className="mini-track"><span style={{width:`${tasks.length?completed/tasks.length*100:0}%`}}/></div></div><div className="mini-progress"><div><span>In progress</span><strong>{pending}</strong></div><div className="mini-track"><span className="in-progress" style={{width:`${tasks.length?pending/tasks.length*100:0}%`}}/></div></div><div className="insight-note"><Sprout size={20}/><p>Try choosing one important task each morning. Small, repeatable actions build lasting momentum.</p></div><a className="export-link" href={`${API}/analytics/export.csv`} target="_blank" rel="noreferrer">Export analytics CSV <ArrowUpRight size={15}/></a></section></div>;
}

function EmptyState({title,text}) { return <div className="empty-state"><span><Sprout size={22}/></span><strong>{title}</strong><p>{text}</p></div>; }

createRoot(document.getElementById("root")).render(<App/>);
