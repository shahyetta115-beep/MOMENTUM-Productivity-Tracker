# MOMENTUM Frontend (Beginner setup)

A sage-green minimal React dashboard for your existing FastAPI backend.

## Requirements
- Python backend already running at `http://127.0.0.1:8000`
- Node.js LTS installed (includes npm)
- VS Code

## Run it
1. Extract `MOMENTUM_Frontend.zip`.
2. In VS Code, choose **File → Open Folder** and select `MOMENTUM_Frontend`.
3. Open **Terminal → New Terminal**.
4. Check Node/npm:
   ```bash
   node -v
   npm -v
   ```
   If either command is not recognized, install Node.js LTS from https://nodejs.org and restart VS Code.
5. Install dependencies:
   ```bash
   npm install
   ```
6. Start the frontend:
   ```bash
   npm run dev
   ```
7. Open the local URL printed by Vite, usually `http://localhost:5173`.

## Important: run both servers
- Backend terminal: `uvicorn app.main:app --reload` from your `MOMENTUM_Backend` folder.
- Frontend terminal: `npm run dev` from your `MOMENTUM_Frontend` folder.
- Keep both terminals open.

## What works
- Dashboard overview and task counts
- Create tasks, search/filter, mark complete/pending, delete tasks
- Daily journal: study hours, sleep, screen time, exercise, mood and notes
- Insights and study-hours chart
- CSV export link from backend

## Backend/API note
This frontend calls `http://127.0.0.1:8000` directly. The backend currently enables CORS for local development.
This is a local prototype. It does not yet implement authentication/login, user accounts, habits, goals or deployment security.
